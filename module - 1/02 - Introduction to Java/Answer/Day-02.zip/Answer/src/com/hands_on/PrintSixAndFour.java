/**
 * 2.  Initialize two integer variables ‘six’ and ‘four’ with the values as
 *     the name says. Then, print the values of 'six' and 'four' to the
 *     console.
 *
 * @author: Shabari K S
 */

package com.hands_on;

public class PrintSixAndFour {
    public static void main(String[] args) {
        byte six = 6, four = 4;
        System.out.println(six+" "+four);
    }
}
