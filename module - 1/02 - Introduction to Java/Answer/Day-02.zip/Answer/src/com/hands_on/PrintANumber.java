/**
 * 1. Initialize an integer variable ‘number’ with the value 100. Then
 *    print the value of ‘number’ to the console
 *
 * @author: Shabari K S
 */
package com.hands_on;

public class PrintANumber {
    public static void main(String[] args) {
        int number = 100;
        System.out.println(number);
    }
}
