package com.hands_on.Question2;

public class FullTimeEmployee extends Employee {
    double salary;

    void calculateSalary() {
        System.out.println("Salary: " + salary);
    }
}
