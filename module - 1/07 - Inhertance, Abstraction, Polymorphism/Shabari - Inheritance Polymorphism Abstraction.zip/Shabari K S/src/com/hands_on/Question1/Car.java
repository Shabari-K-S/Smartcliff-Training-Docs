package com.hands_on.Question1;

public class Car extends Vehicle {
    String model;

    void displayCarInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }
}
