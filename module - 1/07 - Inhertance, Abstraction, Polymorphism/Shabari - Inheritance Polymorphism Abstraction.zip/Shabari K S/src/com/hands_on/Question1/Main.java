package com.hands_on.Question1;

public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        car.brand = "Toyota";
        car.year = 2021;
        car.model = "Corolla";
        car.displayInfo();
        car.displayCarInfo();
    }
}
