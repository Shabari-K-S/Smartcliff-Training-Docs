package com.hands_on.Question11;

interface ElectricVehicle {
    void charge();
}


