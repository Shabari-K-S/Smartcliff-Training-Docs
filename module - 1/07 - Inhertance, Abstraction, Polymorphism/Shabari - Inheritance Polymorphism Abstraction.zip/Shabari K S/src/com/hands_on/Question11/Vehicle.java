package com.hands_on.Question11;

interface Vehicle {
    void start();
    void stop();
}
