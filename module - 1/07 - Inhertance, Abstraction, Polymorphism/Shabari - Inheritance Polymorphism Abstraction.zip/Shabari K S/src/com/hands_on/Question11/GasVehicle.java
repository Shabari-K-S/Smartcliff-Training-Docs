package com.hands_on.Question11;

public interface GasVehicle {
    void refuel();
}

