package com.hands_on.Question10;

abstract class Shape {
    abstract public double calculateArea();
}
