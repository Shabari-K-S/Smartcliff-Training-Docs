package com.hands_on.Question3;

abstract class MenuItem {
    String Name;
    double Price;

    abstract void Cook();
}
