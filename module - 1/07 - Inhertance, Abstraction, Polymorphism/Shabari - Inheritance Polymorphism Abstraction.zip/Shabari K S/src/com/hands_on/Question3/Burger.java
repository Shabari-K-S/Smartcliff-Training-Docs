package com.hands_on.Question3;

class Burger extends MenuItem {
    void Cook() {
        System.out.println("Cooking instructions for Burger:");
        System.out.println("1. Grill the patty.");
        System.out.println("2. Toast the bun.");
        System.out.println("3. Assemble the burger.");
    }
}
