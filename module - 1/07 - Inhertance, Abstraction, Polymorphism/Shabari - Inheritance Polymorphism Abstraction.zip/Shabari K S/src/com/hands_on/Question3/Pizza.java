package com.hands_on.Question3;

class Pizza extends MenuItem {
    void Cook() {
        System.out.println("Cooking instructions for Pizza:");
        System.out.println("1. Roll out the dough.");
        System.out.println("2. Add toppings.");
        System.out.println("3. Bake in the oven.");
    }
}
