package com.hands_on.Question7;

public class Main {
    public static void main(String[] args) {
        StringOverloading demo = new StringOverloading();
        demo.ProcessString("i am ");
        demo.ProcessString("Shabari", 1);
        demo.ProcessString("java", 2);
        demo.ProcessString("programming", 3);
    }
}
