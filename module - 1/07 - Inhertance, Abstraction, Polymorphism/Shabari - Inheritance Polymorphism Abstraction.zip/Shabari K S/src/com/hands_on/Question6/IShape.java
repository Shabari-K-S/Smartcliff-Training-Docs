package com.hands_on.Question6;

interface IShape {
    double calculateArea();
    double calculatePerimeter();
}
