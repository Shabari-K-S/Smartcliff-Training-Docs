package com.hands_on.Question8;

public class Main {
    public static void main(String[] args) {
        AreaOverloading area = new AreaOverloading();
        area.calculateArea(5.5, 10.5);
        area.calculateArea(3.5);
        area.calculateArea(4, 6);
    }
}
