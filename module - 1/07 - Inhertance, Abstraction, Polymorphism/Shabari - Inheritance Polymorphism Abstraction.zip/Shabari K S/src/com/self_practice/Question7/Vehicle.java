package com.self_practice.Question7;

interface Vehicle {
    void start();
    void stop();
}
