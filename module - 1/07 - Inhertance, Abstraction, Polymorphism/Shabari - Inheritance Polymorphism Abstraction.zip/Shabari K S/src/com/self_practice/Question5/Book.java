package com.self_practice.Question5;

class Book {
    String title;
    String author;
    String ISBN;

    Book(String title, String author, String ISBN){
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }
}
