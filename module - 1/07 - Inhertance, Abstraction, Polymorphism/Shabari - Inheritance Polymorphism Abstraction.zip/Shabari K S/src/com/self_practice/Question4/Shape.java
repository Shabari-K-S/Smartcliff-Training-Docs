package com.self_practice.Question4;

abstract class Shape {
    abstract double calculateArea();
    abstract double calculatePerimeter();
}

