package com.self_practice.Question1;

class BankAccount {
    int accountNumber;
    double balance;
    double interestRate;
    void deposit(double amount){
        balance += amount;
    }
}

