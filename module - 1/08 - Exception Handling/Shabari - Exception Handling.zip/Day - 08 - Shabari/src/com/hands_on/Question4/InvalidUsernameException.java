package com.hands_on.Question4;

public class InvalidUsernameException extends Exception {
    InvalidUsernameException(String s){
        super(s);
    }
}
