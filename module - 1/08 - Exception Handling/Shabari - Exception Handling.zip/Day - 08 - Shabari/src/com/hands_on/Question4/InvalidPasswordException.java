package com.hands_on.Question4;

public class InvalidPasswordException extends Exception {
    InvalidPasswordException(String s){
        super(s);
    }
}
