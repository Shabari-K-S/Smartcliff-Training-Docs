package com.hands_on.Question3;

class InvalidInputException extends Exception{
    InvalidInputException(String s){
        super(s);
    }
}
