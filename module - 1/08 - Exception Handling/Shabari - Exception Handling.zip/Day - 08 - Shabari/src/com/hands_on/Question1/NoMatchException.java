package com.hands_on.Question1;

class NoMatchException extends Exception {
    NoMatchException(String message) {
        super(message);
    }
}
