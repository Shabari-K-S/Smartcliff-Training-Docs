package com.hands_on.Question2;

public class InvalidDivisionException extends Exception{
    InvalidDivisionException(String message) {
        super(message);
    }
}
