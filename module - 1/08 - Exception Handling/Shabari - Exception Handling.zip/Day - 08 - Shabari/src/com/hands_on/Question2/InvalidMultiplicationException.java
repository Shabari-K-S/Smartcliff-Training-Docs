package com.hands_on.Question2;

public class InvalidMultiplicationException extends Exception{
    InvalidMultiplicationException(String message) {
        super(message);
    }
}
