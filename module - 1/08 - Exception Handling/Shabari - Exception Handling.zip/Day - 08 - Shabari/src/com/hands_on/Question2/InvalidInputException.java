package com.hands_on.Question2;

public class InvalidInputException extends Exception {
    InvalidInputException(String message) {
        super(message);
    }
}
