package com.self_practice.Question4;

public class PayOutOfBoundsException extends Exception {
    PayOutOfBoundsException(String s){
        super(s);
    }
}
