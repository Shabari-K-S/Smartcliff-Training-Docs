package com.self_practice.Question4;

public class Main {
    public static void main(String[] args) {
        AccountManagement accountManagement = new AccountManagement();
        accountManagement.withdraw(40000);
    }
}
