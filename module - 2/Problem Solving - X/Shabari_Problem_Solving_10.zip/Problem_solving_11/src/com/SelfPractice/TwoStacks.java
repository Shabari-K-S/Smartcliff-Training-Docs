package com.SelfPractice;

import java.util.Scanner;

class TwoStacks {
    private int[] array;
    private int top1; // Top of stack 1 (starts from left)
    private int top2; // Top of stack 2 (starts from right)

    public TwoStacks(int size) {
        array = new int[size];
        top1 = -1; // Initially empty
        top2 = size; // Initially empty
    }

    public void push1(int x) {
        if (top1 + 1 < top2) { // Check if there's space in the array
            array[++top1] = x;
            System.out.println("Pushed " + x + " into Stack 1");
        } else {
            System.out.println("Stack 1 Overflow");
        }
    }

    public void push2(int x) {
        if (top2 - 1 > top1) { // Check if there's space in the array
            array[--top2] = x;
            System.out.println("Pushed " + x + " into Stack 2");
        } else {
            System.out.println("Stack 2 Overflow");
        }
    }

    public int pop1() {
        if (top1 >= 0) {
            int popped = array[top1--];
            System.out.println("Popped " + popped + " from Stack 1");
            return popped;
        }
        System.out.println("Stack 1 Underflow");
        return -1; // Stack 1 is empty
    }

    public int pop2() {
        if (top2 < array.length) {
            int popped = array[top2++];
            System.out.println("Popped " + popped + " from Stack 2");
            return popped;
        }
        System.out.println("Stack 2 Underflow");
        return -1; // Stack 2 is empty
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        TwoStacks twoStacks = new TwoStacks(size);

        while (true) {
            System.out.println("\nEnter your choice:");
            System.out.println("1. Push into Stack 1");
            System.out.println("2. Push into Stack 2");
            System.out.println("3. Pop from Stack 1");
            System.out.println("4. Pop from Stack 2");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            int x;

            switch (choice) {
                case 1:
                    System.out.print("Enter element to push into Stack 1: ");
                    x = scanner.nextInt();
                    twoStacks.push1(x);
                    break;
                case 2:
                    System.out.print("Enter element to push into Stack 2: ");
                    x = scanner.nextInt();
                    twoStacks.push2(x);
                    break;
                case 3:
                    int popped1 = twoStacks.pop1();
                    if (popped1 != -1) {
                        System.out.println("Popped element from Stack 1: " + popped1);
                    }
                    break;
                case 4:
                    int popped2 = twoStacks.pop2();
                    if (popped2 != -1) {
                        System.out.println("Popped element from Stack 2: " + popped2);
                    }
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please enter again.");
            }
        }
    }
}
