package com.SelfPractice;

import java.util.*;

class NextGreaterElementI {
    public int[] nextGreaterElement(int[] nums1, int[] nums2) {
        Map<Integer, Integer> nextGreater = new HashMap<>();
        Deque<Integer> stack = new ArrayDeque<>();
        
        for (int i = nums2.length - 1; i >= 0; i--) {
            while (!stack.isEmpty() && stack.peek() <= nums2[i]) {
                stack.pop();
            }
            if (!stack.isEmpty()) {
                nextGreater.put(nums2[i], stack.peek());
            } else {
                nextGreater.put(nums2[i], -1);
            }
            stack.push(nums2[i]);
        }
        
        int[] result = new int[nums1.length];
        for (int i = 0; i < nums1.length; i++) {
            result[i] = nextGreater.get(nums1[i]);
        }
        
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the size of nums1: ");
        int n1 = scanner.nextInt();
        int[] nums1 = new int[n1];
        System.out.println("Enter elements of nums1:");
        for (int i = 0; i < n1; i++) {
            nums1[i] = scanner.nextInt();
        }


        System.out.print("Enter the size of nums2: ");
        int n2 = scanner.nextInt();
        int[] nums2 = new int[n2];
        System.out.println("Enter elements of nums2:");
        for (int i = 0; i < n2; i++) {
            nums2[i] = scanner.nextInt();
        }

        // Compute next greater elements
        NextGreaterElementI solution = new NextGreaterElementI();
        int[] result = solution.nextGreaterElement(nums1, nums2);

        // Output results
        System.out.println("Next Greater Elements for nums1:");
        System.out.println(Arrays.toString(result));

        scanner.close();
    }
}
