package com.SelfPractice;

import java.util.*;

public class BreakNumber {

    public static void main(String[] args) {
        int N = 4; // Example input
        List<List<Integer>> result = findCombinations(N);
        
        // Printing the result as specified
        System.out.println(N);
        for (List<Integer> combination : result) {
            for (int i = 0; i < combination.size(); i++) {
                System.out.print(combination.get(i));
                if (i < combination.size() - 1) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    public static List<List<Integer>> findCombinations(int N) {
        List<List<Integer>> result = new ArrayList<>();
        backtrack(result, new ArrayList<>(), N, 1);
        return result;
    }

    private static void backtrack(List<List<Integer>> result, List<Integer> current, int remaining, int start) {
        if (remaining == 0) {
            result.add(new ArrayList<>(current));
            return;
        }

        for (int i = start; i <= remaining; i++) {
            current.add(i);
            backtrack(result, current, remaining - i, i);
            current.remove(current.size() - 1);
        }
    }
}

