package com.SelfPractice;

import java.util.*;

public class BasicCalculatorIII {

    public static void main(String[] args) {
        BasicCalculatorIII calculator = new BasicCalculatorIII();
        
        String s1 = "1+1";
        System.out.println(calculator.calculate(s1));  // Output: 2
        
        String s2 = "6-4/2";
        System.out.println(calculator.calculate(s2));  // Output: 4
        
        String s3 = "2*(5+5*2)/3+(6/2+8)";
        System.out.println(calculator.calculate(s3));  // Output: 21
    }

    public int calculate(String s) {
        List<String> tokens = tokenize(s);
        List<String> rpn = shuntingYard(tokens);
        return evaluateRPN(rpn);
    }
    
    private List<String> tokenize(String s) {
        List<String> tokens = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == ' ') {
                continue;
            }
            if (Character.isDigit(c)) {
                sb.append(c);
            } else {
                if (sb.length() > 0) {
                    tokens.add(sb.toString());
                    sb.setLength(0);
                }
                tokens.add(String.valueOf(c));
            }
        }
        if (sb.length() > 0) {
            tokens.add(sb.toString());
        }
        return tokens;
    }
    
    private List<String> shuntingYard(List<String> tokens) {
        List<String> rpn = new ArrayList<>();
        Deque<String> stack = new ArrayDeque<>();
        
        Map<String, Integer> precedence = new HashMap<>();
        precedence.put("+", 1);
        precedence.put("-", 1);
        precedence.put("*", 2);
        precedence.put("/", 2);
        
        for (String token : tokens) {
            if (Character.isDigit(token.charAt(0))) {
                rpn.add(token);
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) {
                    rpn.add(stack.pop());
                }
                stack.pop(); // Pop the '('
            } else {
                while (!stack.isEmpty() && precedence.containsKey(stack.peek())
                        && precedence.get(stack.peek()) >= precedence.get(token)) {
                    rpn.add(stack.pop());
                }
                stack.push(token);
            }
        }
        
        while (!stack.isEmpty()) {
            rpn.add(stack.pop());
        }
        
        return rpn;
    }
    
    private int evaluateRPN(List<String> rpn) {
        Deque<Integer> stack = new ArrayDeque<>();
        
        for (String token : rpn) {
            if (Character.isDigit(token.charAt(0))) {
                stack.push(Integer.parseInt(token));
            } else {
                int operand2 = stack.pop();
                int operand1 = stack.pop();
                switch (token) {
                    case "+":
                        stack.push(operand1 + operand2);
                        break;
                    case "-":
                        stack.push(operand1 - operand2);
                        break;
                    case "*":
                        stack.push(operand1 * operand2);
                        break;
                    case "/":
                        stack.push(operand1 / operand2);
                        break;
                }
            }
        }
        
        return stack.pop();
    }
}

