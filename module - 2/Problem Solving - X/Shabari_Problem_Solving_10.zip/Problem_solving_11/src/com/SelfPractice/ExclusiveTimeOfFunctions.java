package com.SelfPractice;

import java.util.*;

public class ExclusiveTimeOfFunctions {

    public static int[] exclusiveTime(int n, List<String> logs) {
        int[] exclusiveTimes = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        int parevTime = 0;

        for (String log : logs) {
            String[] parts = log.split(":");
            int functionId = Integer.parseInt(parts[0]);
            String action = parts[1];
            int timestamp = Integer.parseInt(parts[2]);

            if (action.equals("start")) {
                if (!stack.isEmpty()) {
                    exclusiveTimes[stack.peek()] += timestamp - prevTime;
                }
                stack.push(functionId);
                prevTime = timestamp;
            } else if (action.equals("end")) {
                exclusiveTimes[stack.pop()] += timestamp - prevTime + 1;
                prevTime = timestamp + 1;
            }
        }

        return exclusiveTimes;
    }

    public static void main(String[] args) {
        int n1 = 2;
        List<String> logs1 = Arrays.asList("0:start:0", "1:start:2", "1:end:5", "0:end:6");
        int[] result1 = exclusiveTime(n1, logs1);
        System.out.println(Arrays.toString(result1));  // Output: [3, 4]

        int n2 = 1;
        List<String> logs2 = Arrays.asList("0:start:0", "0:start:2", "0:end:5", "0:start:6", "0:end:6", "0:end:7");
        int[] result2 = exclusiveTime(n2, logs2);
        System.out.println(Arrays.toString(result2));  // Output: [8]

        int n3 = 2;
        List<String> logs3 = Arrays.asList("0:start:0", "0:start:2", "0:end:5", "1:start:6", "1:end:6", "0:end:7");
        int[] result3 = exclusiveTime(n3, logs3);
        System.out.println(Arrays.toString(result3));  // Output: [7, 1]
    }
}
