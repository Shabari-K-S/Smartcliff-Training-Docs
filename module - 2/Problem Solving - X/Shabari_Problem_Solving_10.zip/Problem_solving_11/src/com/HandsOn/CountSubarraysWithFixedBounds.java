package com.HandsOn;

import java.util.Scanner;

public class CountSubarraysWithFixedBounds {

    public static long countSubarrays(int[] nums, int minK, int maxK) {
        int n = nums.length;
        int lastMinKIndex = -1;
        int lastMaxKIndex = -1;
        int leftBound = -1;
        long count = 0;

        for (int i = 0; i < n; i++) {
            
            if (nums[i] < minK || nums[i] > maxK) {
                leftBound = i;
                lastMinKIndex = -1;
                lastMaxKIndex = -1;
            }
            
            if (nums[i] == minK) {
                lastMinKIndex = i;
            }
            
            if (nums[i] == maxK) {
                lastMaxKIndex = i;
            }
            
            if (lastMinKIndex != -1 && lastMaxKIndex != -1) {
                count += Math.max(0, Math.min(lastMinKIndex, lastMaxKIndex) - leftBound);
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of elements in the array:");
        int n = scanner.nextInt();
        int[] nums = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }

        System.out.println("Enter the value of minK:");
        int minK = scanner.nextInt();

        System.out.println("Enter the value of maxK:");
        int maxK = scanner.nextInt();

        long result = countSubarrays(nums, minK, maxK);
        System.out.println("Number of fixed-bound subarrays: " + result);

        scanner.close();
    }
}

