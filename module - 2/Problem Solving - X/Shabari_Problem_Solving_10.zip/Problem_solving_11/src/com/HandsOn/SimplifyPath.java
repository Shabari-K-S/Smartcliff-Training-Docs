package com.HandsOn;

import java.util.Scanner;
import java.util.Stack;

public class SimplifyPath {

    public static String simplifyPath(String path) {
        Stack<String> stack = new Stack<>();
        String[] components = path.split("/");

        for (String part : components) {
            if (part.isEmpty() || part.equals(".")) {
                // Skip empty parts or current directory indicators
                continue;
            } else if (part.equals("..")) {
                // Pop the stack if we encounter a parent directory indicator
                if (!stack.isEmpty()) {
                    stack.pop();
                }
            } else {
                // Push valid directory names onto the stack
                stack.push(part);
            }
        }

        // Build the simplified path
        StringBuilder simplifiedPath = new StringBuilder("/");
        for (String dir : stack) {
            simplifiedPath.append(dir).append("/");
        }

        // Remove the trailing slash if not the root directory
        if (simplifiedPath.length() > 1) {
            simplifiedPath.setLength(simplifiedPath.length() - 1);
        }

        return simplifiedPath.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Unix-style absolute path:");
        String path = scanner.nextLine();
        System.out.println("Simplified path: " + simplifyPath(path));
        scanner.close();
    }
}
