package com.HandsOn;

import java.util.Scanner;

public class MinimumStringLengthAfterRemovingSubstrings {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		System.out.println(minLength(s));
		sc.close();
	}
	public static int minLength(String s) {
		char arr[] = new char[s.length()];
		int i =-1;
		for (char ch : s.toCharArray()) {
            if (i >= 0 && ((ch == 'B' && arr[i] == 'A') || (ch == 'D' && arr[i] == 'C'))) {
                i--;
            } else {
                arr[++i] = ch;
            }
        }
        return i + 1;
    }
}
