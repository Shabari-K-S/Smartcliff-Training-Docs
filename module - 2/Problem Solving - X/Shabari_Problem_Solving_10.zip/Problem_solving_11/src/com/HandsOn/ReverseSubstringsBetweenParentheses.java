package com.HandsOn;

import java.util.Scanner;
import java.util.Stack;

public class ReverseSubstringsBetweenParentheses {

    public static String reverseParentheses(String s) {
        Stack<StringBuilder> stack = new Stack<>();
        StringBuilder current = new StringBuilder();

        for (char c : s.toCharArray()) {
            if (c == '(') {
                stack.push(current);
                current = new StringBuilder();
            } else if (c == ')') {
                current.reverse();
                current = stack.pop().append(current);
            } else {
                current.append(c);
            }
        }

        return current.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the string with parentheses:");
        String s = scanner.nextLine();
        System.out.println("Resulting string after reversing substrings: " + reverseParentheses(s));
        scanner.close();
    }
}
