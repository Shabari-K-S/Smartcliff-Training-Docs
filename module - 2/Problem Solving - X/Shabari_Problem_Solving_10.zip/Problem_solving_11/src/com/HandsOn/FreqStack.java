package com.HandsOn;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;

class FreqStack {
    private Map<Integer, Integer> freqMap; // Map to store frequency of each element
    private Map<Integer, Stack<Integer>> groupMap; // Map to store stacks of elements by their frequency
    private int maxFreq; // Variable to keep track of the current maximum frequency

    public FreqStack() {
        freqMap = new HashMap<>();
        groupMap = new HashMap<>();
        maxFreq = 0;
    }

    public void push(int val) {
        int freq = freqMap.getOrDefault(val, 0) + 1;
        freqMap.put(val, freq);
        if (!groupMap.containsKey(freq)) {
            groupMap.put(freq, new Stack<>());
        }
        groupMap.get(freq).push(val);
        if (freq > maxFreq) {
            maxFreq = freq;
        }
    }

    public int pop() {
        int val = groupMap.get(maxFreq).pop();
        freqMap.put(val, freqMap.get(val) - 1);
        if (groupMap.get(maxFreq).isEmpty()) {
            maxFreq--;
        }
        return val;
    }

    public static void main(String[] args) {
        FreqStack freqStack = new FreqStack();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1: Push");
            System.out.println("2: Pop");
            System.out.println("3: Exit");

            int choice = scanner.nextInt();
            if (choice == 1) {
                System.out.println("Enter value to push:");
                int value = scanner.nextInt();
                freqStack.push(value);
                System.out.println("Pushed: " + value);
            } else if (choice == 2) {
                int poppedValue = freqStack.pop();
                System.out.println("Popped: " + poppedValue);
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
