package com.HandsOn;

import java.util.Scanner;
import java.util.Stack;

public class ScoreOfParentheses {

    public static int scoreOfParentheses(String s) {
        Stack<Integer> stack = new Stack<>();
        stack.push(0);
        
        for (char c : s.toCharArray()) {
            if (c == '(') {
                stack.push(0);
            } else {
                int innerScore = stack.pop();
                int outerScore = stack.pop();
                int scoreToAdd = Math.max(2 * innerScore, 1);
                stack.push(outerScore + scoreToAdd);
            }
        }
        
        return stack.pop();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the balanced parentheses string:");
        String s = scanner.nextLine();
        System.out.println("Score of the parentheses string: " + scoreOfParentheses(s));
        scanner.close();
    }
}

