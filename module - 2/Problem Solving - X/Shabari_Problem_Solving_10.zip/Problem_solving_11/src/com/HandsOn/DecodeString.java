package com.HandsOn;


import java.util.Stack;
import java.util.Scanner;

public class DecodeString {
    
    public static String decodeString(String s) {
        Stack<Integer> countStack = new Stack<>();
        Stack<StringBuilder> stringStack = new Stack<>();
        StringBuilder currentString = new StringBuilder();
        int k = 0;

        for (char ch : s.toCharArray()) {
            if (Character.isDigit(ch)) {
                k = k * 10 + (ch - '0'); // Construct the number k
            } else if (ch == '[') {
                // Push the current number and current string to their stacks
                countStack.push(k);
                stringStack.push(currentString);
                // Reset currentString and k for the next segment
                currentString = new StringBuilder();
                k = 0;
            } else if (ch == ']') {
                // Pop the number of times to repeat
                int repeatTimes = countStack.pop();
                // Pop the last built string
                StringBuilder decodedString = stringStack.pop();
                // Append the current built string repeated k times to the decoded string
                for (int i = 0; i < repeatTimes; i++) {
                    decodedString.append(currentString);
                }
                // Update the current string to the decoded string
                currentString = decodedString;
            } else {
                // Append current character to current string
                currentString.append(ch);
            }
        }
        return currentString.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the encoded string:");
        String s = scanner.nextLine();
        System.out.println("Decoded string: " + decodeString(s));
        scanner.close();
    }
}
