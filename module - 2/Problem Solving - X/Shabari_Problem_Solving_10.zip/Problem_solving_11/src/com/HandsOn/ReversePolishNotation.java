package com.HandsOn;

import java.util.Scanner;
import java.util.Stack;

class ReversePolishNotation {

    public static int evalRPN(String[] tokens) {
        Stack<Integer> stack = new Stack<>();

        for (String token : tokens) {
            if (token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/")) {
                int b = stack.pop();
                int a = stack.pop();
                int result = 0;

                switch (token) {
                    case "+":
                        result = a + b;
                        break;
                    case "-":
                        result = a - b;
                        break;
                    case "*":
                        result = a * b;
                        break;
                    case "/":
                        result = a / b;
                        break;
                }

                stack.push(result);
            } else {
                stack.push(Integer.parseInt(token));
            }
        }

        return stack.pop();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the tokens of the RPN expression (separated by spaces):");
        String input = scanner.nextLine();

        // Split the input line into tokens
        String[] tokens = input.split(" ");

        int result = evalRPN(tokens);
        System.out.println("The value of the expression is: " + result);

        scanner.close();
    }
}
