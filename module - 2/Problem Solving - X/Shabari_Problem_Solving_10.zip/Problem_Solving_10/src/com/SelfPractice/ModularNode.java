package com.SelfPractice;

import java.util.Scanner;

public class ModularNode {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        System.out.print("Enter the value of k : ");
        int k = sc.nextInt();
        curr = head;

        int val = -1;
        while (curr.next != null) {
            if(curr.data%k == 0)
            {
                if(curr.data>val)
                    val = curr.data;
            }
            curr = curr.next;
        }
        System.out.println(val);
    }
}
