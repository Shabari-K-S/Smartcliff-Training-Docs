package com.SelfPractice;

import java.util.HashSet;
import java.util.Scanner;

public class LinkedListComponents {
    static int numComponents(Node head, int[] nums) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : nums) {
            set.add(num);
        }

        int count = 0;
        boolean inComponent = false;
        Node curr = head;

        while (curr != null) {
            if (set.contains(curr.data)) {
                if (!inComponent) {
                    count++;
                    inComponent = true;
                }
            } else {
                inComponent = false;
            }
            curr = curr.next;
        }

        return count;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list: ");
        int n = sc.nextInt();
        System.out.print("Enter the list elements: ");
        Node head = new Node(sc.nextInt());
        Node curr = head;
        for (int i = 1; i < n; i++) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
        }

        System.out.print("Enter the size of the array: ");
        n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int result = numComponents(head, arr);
        System.out.println(result);

    }
}
