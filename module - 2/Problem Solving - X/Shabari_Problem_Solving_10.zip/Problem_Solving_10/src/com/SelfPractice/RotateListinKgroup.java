package com.SelfPractice;

import java.util.Scanner;

public class RotateListinKgroup {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        System.out.print("Enter k : ");
        int k = sc.nextInt();
        curr = head;
        count = 0;
        while (count < k-1 && curr.next != null) {
            curr = curr.next;
            count++;
        }
        Node curr2 = curr.next;
        curr.next = null;

        Node tra = head;
        Node prev = null;

        while (tra != null) {
            Node next = tra.next;
            tra.next = prev;
            prev = tra;
            tra = next;
        }
        head = prev;
        while (prev.next != null) {
            prev = prev.next;
        }
        prev.next = curr2;
        curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}
