package com.SelfPractice;
import java.util.Scanner;

public class RotatebyKplaces {
        static Node rotateRight(Node head, int k) {
            if (head == null || head.next == null) {
                return head;
            }

            int length = 1;
            Node curr = head;
            while (curr.next != null) {
                length++;
                curr = curr.next;
            }

            k = k % length;

            curr = head;
            for (int i = 0; i < length - k - 1; i++) {
                curr = curr.next;
            }

            Node newHead = curr.next;
            curr.next = null;
            curr = newHead;
            while (curr.next != null) {
                curr = curr.next;
            }
            curr.next = head;

            return newHead;
        }

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the size of the list: ");
            int n = sc.nextInt();
            System.out.print("Enter the elements: ");
            Node head = new Node(sc.nextInt());
            Node curr = head;
            for (int i = 1; i < n; i++) {
                curr.next = new Node(sc.nextInt());
                curr = curr.next;
            }
            System.out.print("Enter the k value: ");
            int k = sc.nextInt();
            head = rotateRight(head, k);
            curr = head;
            while (curr != null) {
                System.out.print(curr.data + " ");
                curr = curr.next;
            }
            System.out.println();
        }
}

