package com.SelfPractice;

import java.util.Scanner;

public class DivideLinkedListintoTwo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        if (head.next == null) {
            System.out.println("Divided list 1: " + head.data);
            System.out.println("Divided list 2: ");
        } else {
            Node odd = head;
            Node even = head.next;
            Node oddHead = odd;
            Node evenHead = even;

            while (even != null && even.next != null) {
                odd.next = even.next;
                odd = odd.next;
                even.next = odd.next;
                even = even.next;
            }

            System.out.print("Divided list 1: ");
            while (oddHead != null) {
                System.out.print(oddHead.data + " ");
                oddHead = oddHead.next;
            }
            System.out.println();
            System.out.print("Divided list 2: ");
            while (evenHead != null) {
                System.out.print(evenHead.data + " ");
                evenHead = evenHead.next;
            }
        }
    }
}
