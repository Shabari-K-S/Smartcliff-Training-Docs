package com.SelfPractice;

import java.util.Scanner;

//class Node {
//    int data;
//    Node next;
//    Node(int data) {
//        this.data = data;
//        this.next = null;
//    }
//}

public class Sort0s1s2s {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 1;
        Node curr = head;
        while (count < n) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        Node zerohead = new Node(-1);
        Node onehead = new Node(-1);
        Node twohead = new Node(-1);

        Node zero = zerohead;
        Node one = onehead;
        Node two = twohead;

        curr = head;
        while (curr != null) {
            if(curr.data == 0) {
                zero.next = curr;
                zero = zero.next;
            } else if (curr.data == 1) {
                one.next = curr;
                one = one.next;
            } else if (curr.data == 2) {
                two.next = curr;
                two = two.next;
            }
            curr = curr.next;
        }
        
        zero.next = (onehead.next != null) ? onehead.next : twohead.next;
        one.next = twohead.next;
        two.next = null;

        Node newHead = (zerohead.next != null) ? zerohead.next : 
                       (onehead.next != null) ? onehead.next : twohead.next;

        curr = newHead;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}
