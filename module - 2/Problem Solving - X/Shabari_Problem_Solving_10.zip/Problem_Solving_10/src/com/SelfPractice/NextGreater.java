package com.SelfPractice;

import java.util.Scanner;

public class NextGreater {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        Node curr = head;
        for (int i = 1; i < n; i++) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
        }

        curr = head;
        while (curr != null) {
            int nextGreater = 0;
            Node temp = curr.next;
            while (temp != null) {
                if (temp.data > curr.data) {
                    nextGreater = temp.data;
                    break;
                }
                temp = temp.next;
            }
            System.out.print(nextGreater + " ");
            curr = curr.next;
        }
    }
}

