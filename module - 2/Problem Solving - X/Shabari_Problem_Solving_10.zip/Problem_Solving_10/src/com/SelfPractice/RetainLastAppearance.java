package com.SelfPractice;

import java.util.Arrays;
import java.util.Scanner;

public class RetainLastAppearance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list1 : ");
        int n = sc.nextInt();
        System.out.print("Enter the list1 elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        int[] arr = new int[n];
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }
        curr = head;
        int i = 0;
        while (curr != null) {
            arr[i] = curr.data;
            curr = curr.next;
            i++;
        }

        for (i=0;i<n;i++)
        {
            for (int j = i+1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    arr[i] = -1;
                }
            }
        }
        Node newHead = new Node(-1);
        Node ptr = newHead;

        for (int j = 0; j < n; j++) {
            if (arr[j] != -1) {
                ptr.next = new Node(arr[j]);
                ptr = ptr.next;
            }
        }

        newHead = newHead.next;
        curr = newHead;
        System.out.print("After retaining last appearance : ");
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}

