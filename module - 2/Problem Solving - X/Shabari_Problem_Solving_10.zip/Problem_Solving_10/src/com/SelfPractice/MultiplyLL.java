package com.SelfPractice;

import java.util.Scanner;

public class MultiplyLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list1 : ");
        int n = sc.nextInt();
        System.out.print("Enter the list1 elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        System.out.print("Enter the size of list2 : ");
        int n2 = sc.nextInt();
        System.out.print("Enter the list2 elements : ");
        Node head2 = new Node(sc.nextInt());
        int count2 = 0;
        Node curr2 = head2;
        while (count2 < n2-1) {
            curr2.next = new Node(sc.nextInt());
            curr2 = curr2.next;
            count2++;
        }

        int a = head.data;
        int b = head2.data;

        curr = head.next;
        while (curr != null) {
            a = (a*10)+curr.data;
            curr = curr.next;
        }
        curr2 = head2.next;
        while (curr2 != null) {
            b = (b*10)+curr2.data;
            curr2 = curr2.next;
        }
        int val = a*b;


        int temp = val;
        int rev = 0;
        while (temp != 0) {
            int rem = temp % 10;
            rev = rev*10+rem;
            temp = temp/10;
        }
        val = rev;
        Node head3 = new Node(val%10);
        curr = head3;
        val /= 10;
        while (val != 0) {
            curr.next = new Node(val%10);
            curr = curr.next;
            val /= 10;
        }
        System.out.print("Multiplication of the two lists is : ");
        curr = head3;
        while (curr != null) {
            System.out.print(curr.data+" ");
            curr = curr.next;
        }
    }
}
