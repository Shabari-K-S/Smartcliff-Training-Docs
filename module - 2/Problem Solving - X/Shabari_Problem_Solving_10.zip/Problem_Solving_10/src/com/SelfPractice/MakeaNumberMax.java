package com.SelfPractice;

import java.util.Scanner;

public class MakeaNumberMax {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        curr = head;
        for(int i = 0; i <= n; i++) {
            curr = head;
            while (curr.next != null) {
                if (curr.data < curr.next.data) {
                    int temp = curr.data;
                    curr.data = curr.next.data;
                    curr.next.data = temp;
                }
                curr = curr.next;
            }
        }
        curr = head;
        int max = 0;
        while (curr != null) {
            max = (max*10) +  curr.data;
            curr = curr.next;
        }
        System.out.println(max);
    }
}

