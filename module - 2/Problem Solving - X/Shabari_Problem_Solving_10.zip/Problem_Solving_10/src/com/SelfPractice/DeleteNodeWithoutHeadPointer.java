package com.SelfPractice;

class ListNode {
    int val;
    ListNode next;
    ListNode(int x) { val = x; }
}

public class DeleteNodeWithoutHeadPointer {
    public static void deleteNode(ListNode del_node) {
        if (del_node == null || del_node.next == null) {
            return; // As per the problem, this case will not happen
        }
        
        // Copy the value from the next node
        del_node.val = del_node.next.val;
        
        // Skip the next node
        del_node.next = del_node.next.next;
    }

    public static void main(String[] args) {
        // Create a sample linked list: 1 -> 2 -> 3 -> 4
        ListNode head = new ListNode(1);
        head.next = new ListNode(2);
        head.next.next = new ListNode(3);
        head.next.next.next = new ListNode(4);

        // Node to be deleted (for example, node with value 3)
        ListNode del_node = head.next.next;

        // Print the linked list before deletion
        System.out.print("Linked list before deletion: ");
        printList(head);

        // Call the deleteNode function
        deleteNode(del_node);

        // Print the linked list after deletion
        System.out.print("Linked list after deletion: ");
        printList(head);
    }

    // Helper function to print the linked list
    public static void printList(ListNode head) {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }
}
