package com.SelfPractice;

import java.util.Scanner;

public class Addoneincrement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        curr = head;
        Node prev = null;

        while (curr.next != null)
        {
            prev = curr;
            curr = curr.next;
        }

        if(curr.data<8)
            curr.data += 1;
        else
        {
            prev.data += 1;
            curr.data = 0;
        }

        curr = head;

        System.out.print("Modified list : ");
        while (curr != null)
        {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}

