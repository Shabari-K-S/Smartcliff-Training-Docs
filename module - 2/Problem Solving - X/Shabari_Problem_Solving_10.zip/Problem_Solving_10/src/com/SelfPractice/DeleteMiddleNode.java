package com.SelfPractice;

import java.util.Scanner;

public class DeleteMiddleNode {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list1 : ");
        int n = sc.nextInt();
        System.out.print("Enter the list1 elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        Node fast = head;
        Node slow = head;
        while (fast.next != null && fast.next.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }
        curr = head;
        while (curr.next != slow && curr.next != null) {
            curr = curr.next;
        }
        curr.next = slow.next;

        curr = head;
        System.out.print("After deleting middle : ");
        while(curr != null)
        {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}
