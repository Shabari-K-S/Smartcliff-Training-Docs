package com.SelfPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class RemoveNodesFromLL {
    static public Node removeNodes(Node head) {
        ArrayList<Integer> ls = new ArrayList<>();
        ArrayList<Integer> res = new ArrayList<>();
        Node temp = head;
        while(temp != null)
        {
            ls.add(temp.data);
            temp = temp.next;
        }
        int n = ls.size();
        int max = ls.get(n-1);
        res.add(max);
        for(int i=n-2;i>=0;i--)
        {
            int val = ls.get(i);
            if(val>=max)
            {
                res.add(val);
                max = val;
            }
        }
        Collections.reverse(res);
        Node new_head = new Node(res.get(0));
        Node temp2 = new_head;
        for(int i=1;i<res.size();i++)
        {
            temp2.next = new Node(res.get(i));
            temp2 = temp2.next;
        }
        return new_head;

    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list1 : ");
        int n = sc.nextInt();
        System.out.print("Enter the list1 elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }
        curr = removeNodes(head);
        System.out.print("After deletion : ");
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }

    }
}

