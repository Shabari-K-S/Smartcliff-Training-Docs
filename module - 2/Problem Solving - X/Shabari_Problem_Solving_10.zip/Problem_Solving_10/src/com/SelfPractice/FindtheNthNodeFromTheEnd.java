package com.SelfPractice;

import java.util.Scanner;
class Node{
	int data;
	Node next;
	Node prev;
	public Object random;
	Node(int data){
		this.data = data;
		this.next = null;
		this.prev = null;
	}
}

public class FindtheNthNodeFromTheEnd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }

        System.out.print("Enter the nth node : ");
        int nth = sc.nextInt();
        curr = head;
        int size = 1;
        while (curr.next != null) {
            curr = curr.next;
            size++;
        }
        int delpos = size - nth+1;
        curr = head;
        count = 1;

        if(delpos==1)
            head = head.next;
        else {
            Node prev = null;
            while (curr.next != null && count < delpos) {
                prev = curr;
                curr = curr.next;
                count++;
            }
            prev.next = curr.next;
        }
        System.out.print("After deletion : ");
        curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}
