package com.SelfPractice;

import java.util.Scanner;

//class Node {
//    int data;
//    Node next;
//
//    Node(int data) {
//        this.data = data;
//        next = null;
//    }
//}

public class DeletioninCircularLinkedList {
    static Node head;
    static int n = 0;

    static void insertAtBeg(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node curr = head;
            while (curr.next != head) {
                curr = curr.next;
            }
            curr.next = newNode;
            newNode.next = head;
            head = newNode;
        }
        n++;
    }

    static void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node curr = head;
            while (curr.next != head) {
                curr = curr.next;
            }
            curr.next = newNode;
            newNode.next = head;
        }
        n++;
    }

    static void insertAtAny(int data, int pos) {
        Node newNode = new Node(data);
        if (pos == 1) {
            insertAtBeg(data);
        } else if (pos == n + 1) {
            insertAtEnd(data);
        } else {
            Node curr = head;
            int count = 1;
            while (count < pos - 1 && curr.next != head) {
                curr = curr.next;
                count++;
            }
            newNode.next = curr.next;
            curr.next = newNode;
            n++;
        }
    }

    static void deleteAtBeg() {
        Node curr = head;
        while (curr.next != head) {
            curr = curr.next;
        }
        head = head.next;
        curr.next = head;
        n--;
    }

    static void deleteAtEnd() {
        Node curr = head;
        Node prev = null;
        if (head == null)
            System.out.println("Empty list ");
        else {
            while (curr.next != head) {
                prev = curr;
                curr = curr.next;
            }
        }
        prev.next = head;
        curr.next = null;
        n--;
    }

    static void deleteAtAny(int pos) {
        if (head == null)
            System.out.println("List is empty");
        else if (pos == 1) {
            deleteAtBeg();
        } else if (pos == n) {
            deleteAtEnd();
        } else {
            Node curr = head;
            int count = 1;
            while (count < pos - 1 && curr.next != head) {
                curr = curr.next;
                count++;
            }
            curr.next = curr.next.next;
            n--;
        }
    }

    static void display() {
        if (head == null) {
            System.out.println("List is empty");
        } else {
            Node curr = head;
            do {
                System.out.print(curr.data + " ");
                curr = curr.next;
            } while (curr != head);
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nCircular Linked List Operations:");
            System.out.println("1. Insert at beginning");
            System.out.println("2. Insert at end");
            System.out.println("3. Insert at any position");
            System.out.println("4. Delete from beginning");
            System.out.println("5. Delete from end");
            System.out.println("6. Delete from any position");
            System.out.println("7. Display");
            System.out.println("8. Exit");

            System.out.print("Enter your choice (1-8): ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter data to insert: ");
                    int data = scanner.nextInt();
                    insertAtBeg(data);
                    break;
                case 2:
                    System.out.print("Enter data to insert: ");
                    data = scanner.nextInt();
                    insertAtEnd(data);
                    break;
                case 3:
                    System.out.print("Enter data to insert: ");
                    data = scanner.nextInt();
                    System.out.print("Enter position: ");
                    int pos = scanner.nextInt();
                    insertAtAny(data, pos);
                    break;
                case 4:
                    deleteAtBeg();
                    break;
                case 5:
                    deleteAtEnd();
                    break;
                case 6:
                    System.out.print("Enter position: ");
                    pos = scanner.nextInt();
                    deleteAtAny(pos);
                    break;
                case 7:
                    display();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 8);

        scanner.close();
    }
}
