package com.SelfPractice;
import java.util.Scanner;

public class CopyListwithRandomPointer {
    static Node copyRandomList(Node head) {
        Node temp = head;

        while (temp != null) {
            Node newNode = new Node(temp.data);
            newNode.next = temp.next;
            temp.next = newNode;
            temp = temp.next.next;
        }

        Node itr = head;
        while (itr != null) {
            if (itr.random != null) {
                itr.next.random = itr.random.next;
            }
            itr = itr.next.next;
        }

        Node dummy = new Node(0);
        itr = head;
        temp = dummy;
        Node fast;
        while (itr != null) {
            fast = itr.next.next;
            temp.next = itr.next;
            itr.next = fast;
            temp = temp.next;
            itr = fast;
        }
        return dummy.next;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list: ");
        int n = sc.nextInt();
        System.out.print("Enter the elements: ");
        Node head = new Node(sc.nextInt());
        Node curr = head;
        for (int i = 1; i < n; i++) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
        }
        System.out.print("Enter the random pointers: ");
        curr = head;
        for (int i = 0; i < n; i++) {
            int randomIndex = sc.nextInt();
            if (randomIndex != -1) {
                curr.random = getNode(head, randomIndex);
            }
            curr = curr.next;
        }
        head = copyRandomList(head);
        curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
        System.out.println();
    }

    static Node getNode(Node head, int index) {
        Node curr = head;
        for (int i = 0; i < index; i++) {
            curr = curr.next;
        }
        return curr;
    }
}
