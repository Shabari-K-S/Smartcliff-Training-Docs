package com.SelfPractice;

import java.util.Scanner;

public class InsertSortedDLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list : ");
        int n = sc.nextInt();
        System.out.print("Enter the elements : ");
        Node head = new Node(sc.nextInt());
        Node curr = head;
        for (int i = 1; i < n; i++) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
        }

        System.out.print("Enter the element to insert : ");
        int ele = sc.nextInt();
        Node inserted = new Node(ele);
        curr = head;
        Node prev = null;

        if (head.data >= ele) {
            inserted.next = head;
            head = inserted;
        } else {
            while (curr != null && curr.data < ele) {
                prev = curr;
                curr = curr.next;
            }
            prev.next = inserted;
            inserted.next = curr;
        }

        curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}

