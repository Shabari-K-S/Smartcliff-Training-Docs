package com.SelfPractice;

import java.util.Scanner;

public class DeleteNnodeafterMnodes {
    static void deleteafterM( Node head, int M, int N)
    {
        Node curr = head, t;
        int count;
        while (curr!=null)
        {

            for (count = 1; count < M && curr != null; count++)
                curr = curr.next;
            if (curr == null)
                return;
            t = curr.next;
            for (count = 1; count <= N && t != null; count++)
            {
                Node temp = t;
                t = t.next;
            }
            curr.next = t;
            curr = t;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of the list1 : ");
        int n = sc.nextInt();
        System.out.print("Enter the list1 elements : ");
        Node head = new Node(sc.nextInt());
        int count = 0;
        Node curr = head;
        while (count < n-1) {
            curr.next = new Node(sc.nextInt());
            curr = curr.next;
            count++;
        }
        System.out.print("Enter m nodes : ");
        int m = sc.nextInt();
        System.out.print("Enter n nodes : ");
        n = sc.nextInt();

        deleteafterM(head, m, n);
        
        curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
}
