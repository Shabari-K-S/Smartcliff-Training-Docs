package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node9 {
    int data;
    Node9 next;

    Node9(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link9 {
    Node9 head = null;
    StringBuilder s = new StringBuilder();

    public void addNode(int data) {
        Node9 newnode = new Node9(data);
        s.append(data);  
        if (head == null) {
            head = newnode;
        } else {
            Node9 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public void printBinaryValue() {
        System.out.println("Integer value: " + Integer.parseInt(s.toString(), 2));
    }
}

public class Binary_9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Link9 obj = new Link9();
        System.out.print("Enter elements (end with -1): ");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        obj.printBinaryValue(); 
    }
}
