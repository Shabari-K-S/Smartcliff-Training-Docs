package com.handson_prblm_sol_10;
import java.util.*;


class Node21{
	int data;
	Node21 next;
	Node21 prev;
	Node21(int data)
	{
		this.data=data;
		this.next=null;
		this.prev=null;
	}
}
class Link21{
	
	Node21 head = null;
	public void create(int data) {
        Node21 newnode = new Node21(data);
        if (head == null) {
            head = newnode;
        } else {
            Node21 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
            newnode.prev = current;
        }
    }
	public void remove()
	{
		Node21 current = head;
		while(current!=null && current.next!=null)
		{
			if(current.data==current.next.data)
			{
				current.prev.next=current.next;
				current.next.prev=current.prev;
			}
			current=current.next;
		}
	}
	  public void display() {
	        Node21 current = head;
	        while (current != null) {
	            System.out.print(current.data + "->");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

}
public class DupliDoubly_21 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
         Link21 obj = new Link21 ();
         int i;
        System.out.println("Enter integers to add to the list (-1 to end):");
        while ((i = sc.nextInt()) != -1) {
            obj.create(i);
        }
       obj.remove();
       obj.display();
	}
}
