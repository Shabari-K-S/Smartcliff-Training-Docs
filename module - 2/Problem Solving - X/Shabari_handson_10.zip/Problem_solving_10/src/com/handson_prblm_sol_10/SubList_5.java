package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node5 {
    int data;
    Node5 next;

    Node5(int data) {
        this.data = data;
        this.next = null;
    }
}

public class SubList_5 {
    private Node5 head;

    public Node5 createNode(int data) {
        return new Node5(data);
    }

    public void addNode(int data) {
        Node5 newNode = createNode(data);
        if (head == null) {
            head = newNode;
        } else {
            Node5 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void display() {
        Node5 current = head;
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("-1");
    }

    public void reverse(int x, int y) {
        if (head == null || x >= y) {
            return;
        }

        Node5 prev = null;
        Node5 current = head;
        for (int i = 1; current != null && i < x; i++) {
            prev = current;
            current = current.next;
        }

        Node5 start = current;
        Node5 end = start.next;

        for (int i = 0; i < y - x; i++) {
            start.next = end.next;
            end.next = current;
            current = end;
            end = start.next;
        }

        if (prev != null) {
            prev.next = current;
        } else {
            head = current;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SubList_5 list = new SubList_5();
        System.out.println("Enter elements: (-1 to stop)");
        while (true) {
            int data = sc.nextInt();
            if (data == -1) {
                break;
            }
            list.addNode(data);
        }
        System.out.println("Enter x and y value:");
        int x = sc.nextInt();
        int y = sc.nextInt();
        sc.close();
        list.reverse(x, y);
        list.display();
    }
}
