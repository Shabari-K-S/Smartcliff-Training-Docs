package com.handson_prblm_sol_10;
import java.util.*;

class Node6 {
    int data;
    Node6 next;

    Node6(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link6 {
    Node6 head = null;

    public void addNode(int data) {
        Node6 newnode = new Node6(data);
        if (head == null) {
            head = newnode;
        } else {
            Node6 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
    public void sort()
    {
    	Node6 current = head;
    	for(Node6 i=current;current.next!=null;current=current.next)
    	{
    		for(Node6 index = current.next;index!=null;index=index.next)
    		{
    			if(current.data>index.data)
    			{
    				int temp = current.data;
    				current.data=index.data;
    				index.data=temp;
    			}
    		}
    	}
    }
    public void display() {
        Node6 current = head;
        if(isEmpty()) {
            System.out.print("List is empty");
        } else {
            while(current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
        }
     }
    	public boolean isEmpty() {
            return head == null;
        }
    }

public class Sort_6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link6 obj = new Link6();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        obj.sort();
        obj.display();
	}

}
