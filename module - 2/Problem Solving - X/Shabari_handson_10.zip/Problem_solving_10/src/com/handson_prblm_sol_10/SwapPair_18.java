package com.handson_prblm_sol_10;

import java.util.*;

public class SwapPair_18 {
    class Node {
        int data;
        Node next;

        Node(int x) {
            this.data = x;
            this.next = null;
        }
    }

    Node head = null;

    public void addNode(int data) {
        Node newnode = new Node(data);
        if (head == null) {
            head = newnode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public void swap(Node current) {
        while (current != null && current.next != null) {
            int temp = current.data;
            current.data = current.next.data;
            current.next.data = temp;
            current = current.next.next;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("The list is empty");
        } else {
            Node current = head;
            while (current != null) {
                System.out.print(current.data + " -> ");
                current = current.next;
            }
            System.out.println("null");
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        SwapPair_18 s = new SwapPair_18();
        System.out.println("Enter the size of the list: ");
        int n = sc.nextInt();
        System.out.println("Enter the values of the list: ");
        for (int i = 0; i < n; i++) {
            s.addNode(sc.nextInt());
        }
        s.display();
        System.out.println("After swapping: ");
        s.swap(s.head);
        s.display();
        sc.close();
    }
}

