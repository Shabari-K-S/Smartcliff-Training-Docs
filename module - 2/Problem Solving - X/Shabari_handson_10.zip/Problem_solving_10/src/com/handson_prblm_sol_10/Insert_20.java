package com.handson_prblm_sol_10;

import java.util.Scanner;



class Node20{
	int data;
	Node20 next;
	Node20(int data)
	{
		this.data=data;
		this.next=null;
	}
}
class Link20
{
	Node20 head = null;
	   public void create(int data) {
	        Node20 newnode = new Node20(data);
	        if (head == null) {
	            head = newnode;
	            newnode.next = head;
	        } else {
	            Node20 current = head;
	            while (current.next != head) {
	                current = current.next;
	            }
	            current.next = newnode;
	            newnode.next = head;
	        }
	    }
     public void insert(int data) {
    	        Node20 newnode = new Node20(data);
      	        if (head == null) {
    	            head = newnode;
    	            newnode.next = head;
    	            return;
    	        }
    	        Node20 current = head;
    	        
    	        while (true) {
    	            if (current.data <= data && data <= current.next.data) {
    	                break;
    	            }    	      
    	            if (current.data > current.next.data) {
    	                if (data <= current.next.data || data >= current.data) {
    	                    break;
    	                }
    	            }
    	            current = current.next;
    	            if (current == head) {
    	                break;
    	            }
    	        }
      	        newnode.next = current.next;
    	        current.next = newnode;
    	    }
	      
    
     public void display() {
         if (head == null) {
             return;
         }
         Node20 current = head;
         System.out.print(current.data + "->");
         current = current.next;
         while (current != head) {
             System.out.print(current.data + "->");
             current = current.next;
         }
         System.out.println(); 
         }
}
public class Insert_20 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link20 obj = new Link20();
        int i;
        System.out.println("Enter integers to add to the list (-1 to end):");
        while ((i = sc.nextInt()) != -1) {
            obj.create(i);
        }
        System.out.print("Enter ele:");
        obj.insert(sc.nextInt());
        obj.display();
	}
}
