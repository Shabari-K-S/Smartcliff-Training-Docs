package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node7 {
    int data;
    Node7 next;

    Node7(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link7 {
    Node7 head = null;
    StringBuilder s = new StringBuilder();

    public void addNode(int data) {
        Node7 newnode = new Node7(data);
        s.append(data);
        if (head == null) {
            head = newnode;
        } else {
            Node7 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public void isPalin() {
        String original = s.toString();
        String reversed = s.reverse().toString();
        s.reverse(); 
        if (original.equals(reversed)) {
            System.out.print("True");
        } else {
            System.out.print("False");
        }
    }
}
public class Palindrome_7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Link7 obj = new Link7();
        System.out.print("Enter elements (end with -1): ");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        obj.isPalin();
    }
}
