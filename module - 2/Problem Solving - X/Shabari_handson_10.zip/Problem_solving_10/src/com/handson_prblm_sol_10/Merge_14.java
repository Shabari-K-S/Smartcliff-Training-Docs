package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node14 {
    int data;
    Node14 next;

    Node14(int data) {
        this.data = data;
        this.next = null;
    }
}

public class Merge_14 {
	    Node14 head;

	    public void Mergesort(Merge_14 list2) {
	        Merge_14 newList = new Merge_14();
	        Node14 current = head;
	        Node14 current2 = list2.head;

	        while (current != null && current2 != null) {
	            if (current.data < current2.data) {
	                newList.insert(current.data);
	                current = current.next;
	            } else {
	                newList.insert(current2.data);
	                current2 = current2.next;
	            }
	        }

	        while (current != null) {
	            newList.insert(current.data);
	            current = current.next;
	        }

	        while (current2 != null) {
	            newList.insert(current2.data);
	            current2 = current2.next;
	        }

	        head = newList.head;
	    }

	    public void insert(int data) {
	        Node14 newNode = new Node14(data);

	        if (head == null) {
	            head = newNode;
	            return;
	        }

	        Node14 last = head;
	        while (last.next != null) {
	            last = last.next;
	        }

	        last.next = newNode;
	    }

	    public void printList() {
	        Node14 current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        Merge_14 list1 = new Merge_14();
	        Merge_14 list2 = new Merge_14();
	        int i = 0, j = 0;
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter integers to add to list 1 (-1 to end):");
	        while ((i = sc.nextInt()) != -1) {
	            list1.insert(i);
	        }
	        System.out.println("Enter integers to add to list 2 (-1 to end):");
	        while ((j = sc.nextInt()) != -1) {
	            list2.insert(j);
	        }
	        sc.close();

	        System.out.println("List1 before merge sort:");
	        list1.printList();

	        System.out.println("List2 before merge sort:");
	        list2.printList();

	        list1.Mergesort(list2);

	        System.out.println("Merged and sorted list:");
	        list1.printList();
	    }
	}

