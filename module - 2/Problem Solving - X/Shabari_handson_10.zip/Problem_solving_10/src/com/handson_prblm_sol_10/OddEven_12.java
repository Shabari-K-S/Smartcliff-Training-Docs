package com.handson_prblm_sol_10;
import java.util.*;

class Node12{
    int data;
    Node12 next;

    Node12(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link12 {
    Node12 head = null;
     StringBuilder s = new StringBuilder();
    public void addNode(int data) {
        Node12 newnode = new Node12(data);
        if (head == null) {
            head = newnode;
        } else {
            Node12 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
    public void altDel()
    {
        Node12 current = head;
        while (current != null && current.next != null) {
        	s.append(current.next.data);
            current.next = current.next.next;
            current = current.next;
        }    
    }
    public void display()
    {
    	Node12 current1 = head;
    	while(current1!=null)
    	{
    		System.out.print(current1.data+" ");
    		current1 = current1.next;
    	}
    	String res = s.toString();
    	for(int i=0;i<res.length();i++)
    	System.out.print(res.charAt(i)+" ");
    }  
}
   
public class OddEven_12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link12 obj = new Link12();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
       obj.altDel();
       obj.display();
	}

}



