package com.handson_prblm_sol_10;
import java.util.*;

class Node15 {
    int data;
    Node15 next;

    Node15(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link15{
	    Node15 head;

	    public void mergeBetween(int a, int b, Link15 list2) {
	        if (a > size() || a < 0 || b > size() || b < 0 || a > b) {
	            System.out.println("Invalid range");
	            return;
	        }

	        if (list2.head == null) {
	            System.out.println("The second list is empty, nothing to merge");
	            return;
	        }

	        Node15 current = head;
	        int count = 1;

	        while (count < a - 1) {
	            current = current.next;
	            count++;
	        }

	        Node15 start = (a > 0) ? current : null;

	        while (count < b) {
	            current = current.next;
	            count++;
	        }

	        Node15 end = current.next;

	        Node15 list2End = list2.head;
	        while (list2End.next != null) {
	            list2End = list2End.next;
	        }
	        list2End.next = end;

	        if (a > 0) {
	            start.next = list2.head;
	        } else {
	            head = list2.head;
	        }
	    }

	    public void addNode(int data) {
	        Node15 newNode = new Node15(data);

	        if (head == null) {
	            head = newNode;
	            return;
	        }

	        Node15 last = head;
	        while (last.next != null) {
	            last = last.next;
	        }

	        last.next = newNode;
	    }

	    public int size() {
	        int size = 0;
	        Node15 current = head;
	        while (current != null) {
	            size++;
	            current = current.next;
	        }
	        return size;
	    }

	    public void printList() {
	        Node15 current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	}


public class MergeBet_15 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        Link15 list1 = new Link15();
	        Link15 list2 = new Link15();
	
	        System.out.print("Enter elements 1 (end with -1): ");
	        int i;
	        while ((i = sc.nextInt()) != -1) {
	            list1.addNode(i);
	        }
	        System.out.print("Enter elements 2 (end with -1): ");
	        int j;
	        while ((j = sc.nextInt()) != -1) {
	            list2.addNode(j);
	        }
		    System.out.print("Enter a and b:");
		    int a =  sc.nextInt();
		    int b =sc.nextInt();
		    list1.mergeBetween(a, b, list2);
		    list1.printList();
	}
}
