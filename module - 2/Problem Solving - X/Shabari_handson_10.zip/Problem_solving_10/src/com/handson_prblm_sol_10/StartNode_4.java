package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node4 {
    int data;
    Node4 next;

    Node4(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link4 {
    Node4 head = null;

    public void addNode(int data) {
        Node4 newnode = new Node4(data);
        if (head == null) {
            head = newnode;
        } else {
            Node4 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
    public int DelAtPos(int pos)
    {
    	int val=0;
    	if(head==null)
    	{
    		System.out.print("List is Empty");
    	}
    	else
    	{
    		Node4 current = head;
    		int cur=1;
    		while(cur<pos-1 && current.next!=null)
    		{
    			current = current.next;
    			cur++;
    		}
    		 val = current.next.data;
    		current.next=current.next.next;
    	}
    	return val;
    }
    public void insertAtBeg(int val)
    {
    	Node4 newnode = new Node4(val);
    	newnode.next=head;
    	head=newnode;
    }
    public void display() {
        Node4 current = head;
        if(isEmpty()) {
            System.out.print("List is empty");
        } else {
            while(current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
        }
 }
    	public boolean isEmpty() {
            return head == null;
        }
    	  public int size() {
    	        Node4 current = head;
    	        int s = 0;
    	        while (current != null) {
    	            current = current.next;
    	            s++;
    	        }
    	        return s;
    	    }
    }
public class StartNode_4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link4 obj = new Link4();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        System.out.print("Enter n:");
        int n =sc.nextInt();
        int size = obj.size();
        int da = obj.DelAtPos((size-n)+1);
        obj.insertAtBeg(da);
        obj.display();
	}

}
