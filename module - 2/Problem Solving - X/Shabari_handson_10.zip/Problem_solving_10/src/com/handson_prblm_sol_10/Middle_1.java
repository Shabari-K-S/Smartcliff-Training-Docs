package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node1 {
    int data;
    Node1 next;

    Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link1 {
    Node1 head = null;

    public void addNode(int data) {
        Node1 newnode = new Node1(data);
        if (head == null) {
            head = newnode;
        } else {
            Node1 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public void getEle(int pos) {
        if (head == null) {
            System.out.print("List is empty");
        } else {
            Node1 current = head;
            int cur = 1;
            while (cur < pos && current != null) {
                current = current.next;
                cur++;
            }
            while (current != null) {
                System.out.print(current.data + " ");
                current = current.next;
            }
        }
    }

    public int size() {
        Node1 current = head;
        int s = 0;
        while (current != null) {
            current = current.next;
            s++;
        }
        return s;
    }
}

public class Middle_1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Link1 obj = new Link1();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        int size = obj.size();
        int mid = (size % 2 == 0) ? (size / 2) + 1 : (size / 2) + 1;
        obj.getEle(mid);
    }
}
