package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node13 {
    int data;
    Node13 next;

    Node13(int data) {
        this.data = data;
        this.next = null; 
    }
}

class Link13 {
    Node13 head = null;

    public void addNode(int data) {
        Node13 newnode = new Node13(data);
        if (head == null) {
            head = newnode;
        } else {
            Node13 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public void delAtEnd() {
        if (head == null) {
            System.out.print("List is empty");
            return;
        }
        Node13 current = head;
        Node13 prev = null;
        while (current.next != null) {
            prev = current;
            current = current.next;
        }
        if (prev == null) { 
            head = null;
        } else {
            prev.next = null;
        }
    }

    public void insertAt(int index, int data) {
        Node13 newnode = new Node13(data);
        if (index == 0) {
            newnode.next = head;
            head = newnode;
            return;
        }

        Node13 current = head;
        for (int i = 0; i < index - 1 && current != null; i++) {
            current = current.next;
        }

        if (current != null) {
            newnode.next = current.next;
            current.next = newnode;
        }
    }

    public int size() {
        int count = 0;
        Node13 current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public void reorderList() {
        int count = 2;
        Node13 currentnode = head;
        while (count <= size() - 1) {
            Node13 current = currentnode;
            while (current.next != null) {
                current = current.next;
            }
            int temp = current.data;
            delAtEnd();
            insertAt(count - 1, temp);
            count += 2;
            currentnode = currentnode.next;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        else {
        Node13 current = head;
        while (current != null) { 
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();   
      }}
}

public class Reorder_13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Link13 obj = new Link13();
        System.out.print("Enter elements (end with -1): ");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        obj.reorderList(); 
        obj.display();
        sc.close();
    }
}
