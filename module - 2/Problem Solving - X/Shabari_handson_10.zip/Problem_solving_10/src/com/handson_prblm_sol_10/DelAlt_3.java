package com.handson_prblm_sol_10;
import java.util.*;

class Node3{
    int data;
    Node3 next;

    Node3(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link3 {
    Node3 head = null;

    public void addNode(int data) {
        Node3 newnode = new Node3(data);
        if (head == null) {
            head = newnode;
        } else {
            Node3 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
    public void altDel()
    {
        Node3 current = head;
        while (current != null && current.next != null) {
            current.next = current.next.next;
            current = current.next;
        }
    	Node3 current1 = head;
    	while(current1!=null)
    	{
    		System.out.print(current1.data+" ");
    		current1 = current1.next;
    	}
    }
}
   
public class DelAlt_3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link3 obj = new Link3();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
       obj.altDel();
	}

}
