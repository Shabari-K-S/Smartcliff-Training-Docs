package com.handson_prblm_sol_10;
import java.util.*;



class Node11 {
    int data;
    Node11 next;

    Node11(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link11 {
	StringBuilder s = new StringBuilder();
    Node11 head = null;
    public void addNode(int data) {
        Node11 newNode = new Node11(data);
        if(head == null)
        	head=newNode;
        else
        {
        	newNode.next=head;
        	head=newNode;
        }
    } 
    public String display() {
    	s.replace(0, s.length(),"");
        Node11 current = head;
        if(head==null) {
            System.out.print("List is empty");
        } else {
            while(current != null) {
            	s.append(current.data);
                current = current.next;
            }
        }
        return s.toString();
        
 }
     	 
 }
public class AddTwo_11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link11 obj = new Link11();
        Link11 obj1 = new Link11();
        System.out.print("Enter elements for list 1 (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        System.out.print("Enter elements for list 2 (end with -1):");
        int j;
        while ((j= sc.nextInt()) != -1) {
            obj1.addNode(j);
        }
        int sum = Integer.parseInt(obj.display())+Integer.parseInt(obj1.display());
        StringBuilder res = new StringBuilder(Integer.toString(sum));
        res.reverse();
        for(int k=0;k<res.length();k++)
        {
        	System.out.print(res.charAt(k)+" ");
        }
	}
}


