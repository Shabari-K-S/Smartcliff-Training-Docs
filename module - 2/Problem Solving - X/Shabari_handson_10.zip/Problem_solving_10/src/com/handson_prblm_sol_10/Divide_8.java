package com.handson_prblm_sol_10;
import java.util.*;

class Node8{
    int data;
    Node8 next;

    Node8(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link8 {
    Node3 head = null;
     StringBuilder s = new StringBuilder();
    public void addNode(int data) {
        Node3 newnode = new Node3(data);
        if (head == null) {
            head = newnode;
        } else {
            Node3 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
    public void altDel()
    {
        Node3 current = head;
        while (current != null && current.next != null) {
        	s.append(current.next.data);
            current.next = current.next.next;
            current = current.next;
        }    
    }
    public void display()
    {
    	Node3 current1 = head;
    	while(current1!=null)
    	{
    		System.out.print(current1.data+" ");
    		current1 = current1.next;
    	}
    	System.out.println();
    	String res = s.toString();
    	for(int i=0;i<res.length();i++)
    	System.out.print(res.charAt(i)+" ");
    }  
}
   
public class Divide_8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link8 obj = new Link8();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
       obj.altDel();
       obj.display();
	}

}

