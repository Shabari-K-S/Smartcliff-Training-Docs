package com.handson_prblm_sol_10;

import java.util.Scanner;



class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class Detect_17{
    private Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void cycledisplay(int pos) {
    	Node dummy = new Node(0);
        Node current = head;
        int c = 0;
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        while (current != null) {
        	if(pos == c) {
        		System.out.print(current.data + " -> ");
        		dummy.data= current.data;
        		pos =-1;
        	}
        	else {
        		System.out.print(current.data + " -> ");
        		c++;
        	}
            current = current.next;
        }
        System.out.println(dummy.data);
    }

    public int getSize() {
		int size=0;
		Node current = head;
		while(current != null) {
			size++;
			current = current.next;
		}
		return size;
	}
	
    public void display() {
		Node current = head;
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		current = head;
		while(current != null) {
			System.out.print(current.data+"->");
			current = current.next;
		}
		System.out.print("-1");
		
	}
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Detect_17 list = new Detect_17();
        System.out.println("Enter elements for the list (-1 to stop):");
        while (true) {
            int data = sc.nextInt();
            if (data == -1) {
                break;
            } else {
                list.addNode(data);
            }
        }
        System.out.println("Enter position");
        int pos = sc.nextInt();
        sc.close();
        System.out.println("Cycle formed");
        list.cycledisplay(pos);
        if(pos<0 || pos>list.getSize()) {
        	System.out.println("False");
        }
        else {
        	System.out.println("True");
        }
        System.out.println("Cycle remove");
        list.display();
        
    }
}