package com.handson_prblm_sol_10;
import java.util.*;

class Node19{
	int data;
	Node19 next;
	Node19(int data)
	{
		this.data=data;
		this.next=null;
	}
}

class Link19{
	Node19 head = null;
	Node19 current = head;
	 public void addNode(int data) {
	        Node19 newnode = new Node19(data);
	        if (head == null) {
	            head = newnode;
	        } else {
	            Node19 current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newnode;
	        }
	    }
	 public void display(int x) {
		 Link19 ans1 = new Link19();
		 Link19 ans2 = new Link19();
	        Node19 current = head;
	        if(head==null) {
	            System.out.print("List is empty");
	        } else {
	            while(current != null) {
	            	if(current.data<x) {
	            	    ans1.addNode(current.data);
	            	}
	            	else
	            	{
	            		ans2.addNode(current.data);
	            	}
	            	
	   	            current = current.next;
	            }
	            ans1.dis();
	            ans2.dis();
	        }
	 }
	 public void dis()
	 {
		        if (head == null) {
		            System.out.println("List is empty");
		            return;
		        }
		        else {
		        Node19 current = head;
		        while (current != null) { 
		            System.out.print(current.data + " ");
		            current = current.next;
		        } 
		      }}
	 }
	    

public class Partition_19 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        Link19 obj = new Link19();
	        Link19 ans1 = new Link19();
	        Link19 ans2 = new Link19();
	        System.out.print("Enter elements (end with -1): ");
	        int i;
	        while ((i = sc.nextInt()) != -1) {
	            obj.addNode(i);
	        }
	        System.out.print("Enter x:");
	        int x = sc.nextInt();
	        obj.display(x);
	        
	}
}
