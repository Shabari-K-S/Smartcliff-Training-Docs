package com.handson_prblm_sol_10;
import java.util.*;

class Node10 {
    int data;
    Node10 next, prev;

    Node10(int data) {
        this.data = data;
        next = prev = null;
    }
}
 class Link10 {
    Node10 head;
	public void create(int data) {
        Node10 newnode = new Node10(data);
        if (head == null) {
            head = newnode;
        } else {
            Node10 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
            newnode.prev = current;
        }
    }

    public int countTriplets(int X) {
        if (head == null) {
            return 0;
        }

        Node10 current, first, last;
        int count = 0;

        last = head;
        while (last.next != null) {
            last = last.next;
        }
        for (current = head; current != null; current = current.next) {
            int target = X - current.data;
            first = current.next;
            while (first != null && last != null && first != last && last.next != first) {
                int sum = first.data + last.data;

                if (sum == target) {
                    count++;
                    first = first.next;
                    last = last.prev;
                } else if (sum < target) {
                    first = first.next;
                } else {
                    last = last.prev;
                }
            }
            last = head;
            while (last.next != null) {
                last = last.next;
            }
        }

        return count;
    }
}

public class Triplet_10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link10 obj = new Link10 ();
        int i;
       System.out.println("Enter integers to add to the list (-1 to end):");
       while ((i = sc.nextInt()) != -1) {
           obj.create(i);
       }
      System.out.print("Enter target:");
      int tar = sc.nextInt();
     System.out.print(obj.countTriplets(tar));
	}

}
