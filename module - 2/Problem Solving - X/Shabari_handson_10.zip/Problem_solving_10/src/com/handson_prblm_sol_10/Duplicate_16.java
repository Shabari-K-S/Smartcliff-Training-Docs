package com.handson_prblm_sol_10;

import java.util.Scanner;

class Node16{
	int data;
	Node16 next;
	Node16(int data)
	{
		this.data=data;
		this.next = null;
	}
}

class Link16{
	Node16 head = null;
	public void addNode(int data)
	{
		Node16 newnode = new Node16(data);
		if(head==null)
		{
			head = newnode;
		}
		else
		{
			Node16 current = head;
			while(current.next!=null)
			{
				current = current.next;
			}
			current.next=newnode;
		}
	}
	public void remove() {
        if (head == null) {
            return;
        }
        Node16 current = head;
        Node16 prev = null;
        while (current != null) {
            boolean isDup = false;
            while (current.next != null && current.data == current.next.data) {
                current = current.next;
                isDup = true;
            }
            if (isDup) {
                current = current.next; 
                if (prev != null) {
                    prev.next = current; 
                } 
                else {
                    head = current;
                }
            } else {
                if (prev == null) {
                    prev = head; 
                } 
                else {
                    prev = prev.next; 
                }
                current = current.next;
            }
        }	
    }
	public void display()
	{
		
		if(head==null)
			System.out.print("List is empty");
		else
		{
			Node16 current = head;
			while(current!=null)
			{
		      System.out.print(current.data+" ");
		      current = current.next;
			}
		}
	}
}
public class Duplicate_16 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        Link16 obj = new Link16();
	        System.out.print("Enter elements (end with -1):");
	        int i;
	        while ((i = sc.nextInt()) != -1) {
	            obj.addNode(i);
	        }
	        obj.remove();
	        obj.display();
	}
}
