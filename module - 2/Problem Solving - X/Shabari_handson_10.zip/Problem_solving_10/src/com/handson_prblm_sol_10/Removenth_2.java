package com.handson_prblm_sol_10;
import java.util.*;

class Node2 {
    int data;
    Node2 next;

    Node2(int data) {
        this.data = data;
        this.next = null;
    }
}

class Link2 {
    Node2 head = null;

    public void addNode(int data) {
        Node2 newnode = new Node2(data);
        if (head == null) {
            head = newnode;
        } else {
            Node2 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }
   
    public void DelAtPos(int pos)
    {
    	if(head==null)
    	{
    		System.out.print("List is Empty");
    	}
    	else
    	{
    		Node2 current = head;
    		int cur=1;
    		while(cur<pos-1 && current.next!=null)
    		{
    			current = current.next;
    			cur++;
    		}
    		current.next=current.next.next;
    	}
    }
    	 public void display() {
    	        Node2 current = head;
    	        if(isEmpty()) {
    	            System.out.print("List is empty");
    	        } else {
    	            while(current != null) {
    	                System.out.print(current.data + " ");
    	                current = current.next;
    	            }
    	        }
    	 }
    	    	public boolean isEmpty() {
    	            return head == null;
    	        }
    	    	  public int size() {
    	    	        Node2 current = head;
    	    	        int s = 0;
    	    	        while (current != null) {
    	    	            current = current.next;
    	    	            s++;
    	    	        }
    	    	        return s;
    	    	    }
    	    }
public class Removenth_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        Link2 obj = new Link2();
        System.out.print("Enter elements (end with -1):");
        int i;
        while ((i = sc.nextInt()) != -1) {
            obj.addNode(i);
        }
        System.out.print("Enter n:");
        int n =sc.nextInt();
        int size = obj.size();
        obj.DelAtPos((size-n)+1);
        obj.display();
	}

}
