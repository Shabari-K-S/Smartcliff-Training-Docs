package com.HandsOn;

import java.util.Scanner;
import java.util.Stack;

public class RemoveAdjacentDuplicates {

    public static String removeDuplicates(String s, int k) {
        Stack<Pair> stack = new Stack<>();

        for (char c : s.toCharArray()) {
            if (!stack.isEmpty() && stack.peek().character == c) {
                stack.peek().count++;
                if (stack.peek().count == k) {
                    stack.pop();
                }
            } else {
                stack.push(new Pair(c, 1));
            }
        }

        StringBuilder result = new StringBuilder();
        for (Pair pair : stack) {
            for (int i = 0; i < pair.count; i++) {
                result.append(pair.character);
            }
        }

        return result.toString();
    }

    static class Pair {
        char character;
        int count;

        Pair(char character, int count) {
            this.character = character;
            this.count = count;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the string:");
        String s = scanner.nextLine();
        System.out.println("Enter the value of k:");
        int k = scanner.nextInt();
        System.out.println("Resulting string after removing duplicates: " + removeDuplicates(s, k));
        scanner.close();
    }
}

