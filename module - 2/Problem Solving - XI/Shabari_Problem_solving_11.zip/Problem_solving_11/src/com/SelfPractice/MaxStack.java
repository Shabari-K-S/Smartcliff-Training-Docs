package com.SelfPractice;

import java.util.Stack;

class MaxStack {
    private Stack<Integer> stack;
    private Stack<Integer> maxStack;

    public MaxStack() {
        stack = new Stack<>();
        maxStack = new Stack<>();
    }

    // Function to push element onto the stack
    public void specialPush(int value) {
        stack.push(value);
        if (maxStack.isEmpty() || value >= maxStack.peek()) {
            maxStack.push(value);
        }
    }

    // Function to pop element from the stack
    public void specialPop() {
        if (!stack.isEmpty()) {
            int popped = stack.pop();
            if (popped == maxStack.peek()) {
                maxStack.pop();
            }
        }
    }

    // Function to get the top element of the stack
    public int specialTop() {
        if (!stack.isEmpty()) {
            return stack.peek();
        }
        return -1; // Stack is empty
    }

    // Function to get the maximum element in the stack
    public int specialMax() {
        if (!maxStack.isEmpty()) {
            return maxStack.peek();
        }
        return -1; // Stack is empty
    }

    public static void main(String[] args) {
        MaxStack stack = new MaxStack();

        // Sample Input
        int[][] queries = {
            {1, 5},
            {1, 4},
            {1, 6},
            {1, 1},
            {3},
            {4},
            {2},
            {2},
            {3},
            {4}
        };

        for (int[] query : queries) {
            int type = query[0];
            if (type == 1) {
                int value = query[1];
                stack.specialPush(value);
                System.out.println("Pushed " + value + " into stack");
            } else if (type == 2) {
                stack.specialPop();
                System.out.println("Popped from stack");
            } else if (type == 3) {
                int top = stack.specialTop();
                System.out.println("Top of stack: " + top);
            } else if (type == 4) {
                int max = stack.specialMax();
                System.out.println("Max element in stack: " + max);
            }
        }
    }
}
