package com.SelfPractice;

import java.util.*;

public class GenerateBinaryNumbers {

    public static void generateBinaryNumbers(int N) {
        Queue<String> queue = new LinkedList<>();
        queue.offer("1"); // Start with "1"

        for (int i = 0; i < N; i++) {
            String current = queue.poll();
            System.out.print(current + " ");

            // Append '0' and '1' to current binary string and enqueue them
            queue.offer(current + "0");
            queue.offer(current + "1");
        }
    }

    public static void main(String[] args) {
        int N = 5; // Example: N = 5
        generateBinaryNumbers(N);
    }
}
