import java.util.*;

public class NumberOfVisiblePeople {

    public static void main(String[] args) {
        int[] heights1 = {10, 6, 8, 5, 11, 9};
        int[] result1 = canSeePersonsCount(heights1);
        System.out.println(Arrays.toString(result1));  // Expected output: [3, 1, 2, 1, 1, 0]

        int[] heights2 = {5, 1, 2, 3, 10};
        int[] result2 = canSeePersonsCount(heights2);
        System.out.println(Arrays.toString(result2));  // Expected output: [4, 1, 1, 1, 0]
    }

    public static int[] canSeePersonsCount(int[] heights) {
        int n = heights.length;
        int[] answer = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();

        for (int i = n - 1; i >= 0; i--) {
            while (!stack.isEmpty() && heights[i] > heights[stack.peek()]) {
                answer[i]++;
                stack.pop();
            }
            if (!stack.isEmpty()) {
                answer[i]++;
            }
            stack.push(i);
        }

        return answer;
    }
}

