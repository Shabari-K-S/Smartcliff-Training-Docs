package com.SelfPractice;

import java.util.PriorityQueue;

class MinimumCostOfRopes {
    public static long minCostToConnectRopes(int[] ropes) {
        // Edge case: if there's only one rope, no cost needed
        if (ropes.length <= 1) {
            return 0;
        }

        // Create a min-heap priority queue
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        
        // Add all ropes to the min-heap
        for (int rope : ropes) {
            minHeap.offer(rope);
        }
        
        long totalCost = 0;

        // While there are more than one rope in the heap
        while (minHeap.size() > 1) {
            // Extract two smallest ropes
            int first = minHeap.poll();
            int second = minHeap.poll();

            int currentCost = first + second;
            totalCost += currentCost;

            minHeap.offer(currentCost);
        }

        return totalCost;
    }

    public static void main(String[] args) {
        // Example usage
        int[] arr1 = {4, 3, 2, 6};
        System.out.println("Minimum cost for arr1: " + minCostToConnectRopes(arr1)); // Output: 29
        
        int[] arr2 = {4, 2, 7, 6, 9};
        System.out.println("Minimum cost for arr2: " + minCostToConnectRopes(arr2)); // Output: 62
    }
}
