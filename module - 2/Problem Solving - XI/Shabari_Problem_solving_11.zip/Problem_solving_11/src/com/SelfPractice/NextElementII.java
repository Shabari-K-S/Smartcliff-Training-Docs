package com.SelfPractice;

import java.util.*;

public class NextElementII {

    public static int[] nextGreaterElements(int[] nums) {
        int n = nums.length;
        int[] result = new int[n];
        Arrays.fill(result, -1);
        Deque<Integer> stack = new ArrayDeque<>();
        
        // Double the array to handle circular nature
        int[] doubledNums = new int[2 * n];
        for (int i = 0; i < 2 * n; i++) {
            doubledNums[i] = nums[i % n];
        }
        
        // Process the doubled array to find next greater elements
        for (int i = 0; i < 2 * n; i++) {
            while (!stack.isEmpty() && doubledNums[i] > doubledNums[stack.peek()]) {
                int index = stack.pop();
                if (index < n) {
                    result[index] = doubledNums[i];
                }
            }
            if (i < n) {
                stack.push(i);
            }
        }
        
        return result;
    }

    public static void main(String[] args) {
        int[] nums1 = {1, 2, 1};
        int[] result1 = nextGreaterElements(nums1);
        System.out.println(Arrays.toString(result1));  // Output: [2, -1, 2]
        
        int[] nums2 = {1, 2, 3, 4, 3};
        int[] result2 = nextGreaterElements(nums2);
        System.out.println(Arrays.toString(result2));  // Output: [2, 3, 4, -1, 4]
    }
}
